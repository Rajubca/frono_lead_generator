import uuid
import re
import json
import asyncio
import time
from queue import Queue
from fastapi import FastAPI, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

# --- IMPORTS ---
from models.schemas import LeadCreate, LeadResponse
from llm.groq_client import GroqClient 
from agent.health import check_health
from agent.intent_detector import detect_intent
from agent.rag_prompt import build_prompt
from agent.lead_scoring import LeadScorer
from search.retriever import retrieve_context
from search.leads_repo import create_lead
from services.email_service import send_email
from services.email_templates import customer_confirmation_email, sales_notification_email
from config import SALES_EMAIL, BOT_NAME, STRICT_SYSTEM_PROMPT

# ---------------------------------------------------
# GLOBAL STORES
# ---------------------------------------------------
user_queues = {}
user_scorers = {} 

app = FastAPI(title="Frono AI Agent")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

llama = GroqClient()

# ---------------------------------------------------
# SCHEMAS
# ---------------------------------------------------
class PromptRequest(BaseModel):
    prompt: str
    session_id: str 

# ---------------------------------------------------
# ENDPOINTS
# ---------------------------------------------------

@app.get("/health")
def health():
    return check_health()

@app.post("/chat/stream")
def chat_stream(req: PromptRequest):
    session_id = req.session_id
    print(f"🔹 [POST] Received prompt from {session_id}: {req.prompt}")

    # 1. ROBUST INIT (Create Queue & Scorer if missing)
    if (session_id not in user_queues) or (session_id not in user_scorers):
        user_queues[session_id] = Queue()
        user_scorers[session_id] = LeadScorer()
    
    user_queue = user_queues[session_id]
    scorer = user_scorers[session_id]

    # 2. INTENT & SCORING
    intent = detect_intent(req.prompt)
    current_score = scorer.update(intent, req.prompt)
    print(f"🔸 Intent: {intent} | Score: {current_score}")

    # --- A. LEAD CAPTURE ---
    if intent == "LEAD_SUBMISSION":
        email_match = re.search(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}", req.prompt)
        if email_match:
            email = email_match.group(0)
            create_lead({
                "email": email, 
                "intent": f"CHAT_CAPTURE (Score: {current_score})", 
                "lead_score": current_score, 
                "consent": True
            })
            scorer.mark_captured()
            
            reply = f"Thanks! I've saved {email}. I'll send those details shortly. 🎁"
            user_queue.put(reply)
            user_queue.put("__END__")
            return {"status": "lead_captured"}

    # --- B. AFFIRMATION ---
    if intent == "AFFIRMATION":
        reply = "Great! Please type your email address below, and I'll send the code right away. 👇"
        user_queue.put(reply)
        user_queue.put("__END__")
        return {"status": "asking_for_email"}

    # --- C. CLOSING ---
    if intent == "CLOSING":
        reply = "You're welcome! Feel free to chat again if you need anything. 👋"
        user_queue.put(reply)
        user_queue.put("__END__")
        return {"status": "finished_early"}

    # --- D. STANDARD RAG ---
    context = retrieve_context(req.prompt, intent)
    system_instruction = STRICT_SYSTEM_PROMPT

    # Hook Injection
    if scorer.should_trigger_hook():
        print("🔥 HOT LEAD: Injecting Sales Hook")
        hook_instruction = (
            "\n\n[HIDDEN INSTRUCTION]:\n"
            "The user seems very interested.\n"
            "After answering, politely mention that you can email them "
            "a 5% Discount Code if they provide their email.\n"
            "Keep this offer casual."
        )
        system_instruction += hook_instruction

    if intent == "BROWSING":
        final_prompt = (
            f"You are {BOT_NAME}.\nContext: {context}\nUser: '{req.prompt}'\n"
            "Reply warmly. Mention a category (Garden, Christmas). Keep it brief."
        )
    else:
        final_prompt = build_prompt(req.prompt, context, intent)

    # STREAMING TO QUEUE
    # We put tokens into the queue. The SSE endpoint reads them.
    for token in llama.stream(prompt=final_prompt, system_prompt=system_instruction):
        user_queue.put(token)

    user_queue.put("__END__")
    return {"status": "started"}


# In app.py

@app.get("/chat/stream/events/{session_id}")
async def chat_stream_events(session_id: str, request: Request):
    print(f"📡 [SSE] Client Connected: {session_id}")
    
    if session_id not in user_queues:
        user_queues[session_id] = Queue()

    async def event_generator():
        q = user_queues[session_id]
        
        while True:
            if await request.is_disconnected():
                break

            if not q.empty():
                token = q.get()
                
                if token == "__END__":
                    # End of stream signal
                    yield "event: end\ndata: END\n\n"
                    continue 
                
                # --- THE FIX: JSON ENCODE THE DATA ---
                # This ensures newlines (\n) don't break the stream
                data = json.dumps({"text": token})
                yield f"data: {data}\n\n"
                
                await asyncio.sleep(0.01)
            else:
                await asyncio.sleep(0.05) 

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        }
    )
# ... (Lead Endpoint logic remains the same) ...
@app.post("/lead", response_model=LeadResponse)
def capture_lead(lead: LeadCreate, background_tasks: BackgroundTasks):
    result = create_lead(lead.dict())
    if lead.email and lead.consent:
         # Email logic...
        background_tasks.add_task(
            send_email,
            lead.email,
            "Thanks for contacting Frono",
            customer_confirmation_email()
        )
        background_tasks.add_task(
            send_email,
            SALES_EMAIL,
            "New Lead Captured",
            sales_notification_email(
                email=lead.email,
                intent=lead.intent,
                score=lead.lead_score
            )
        )
    return result